#!/usr/bin/env python3
"""
etl_pipeline.py - Pipeline ETL de UrbanPulse IoT
Autores: Juanjose Villamizar, Angello Corredor, Antony Marin - Docente: Camilo Fierro
=================================================
Extrae lecturas heterogéneas de sensores (JSON) y el catálogo de ubicaciones (CSV),
las limpia/normaliza/enriquece y las carga en MongoDB. Además exporta CSV "procesados"
que alimentan la carga del grafo en Neo4j (ver neo4j_urbanpulse.cypher).

Fases
-----
 1. EXTRACT   : lee nodos_ubicacion.csv y sensores_lecturas.json.
 2. TRANSFORM : - unifica nombres de campos (sensor_id/id_sensor, pm25/pm2_5/PM2.5, ...)
                - unifica fechas (ISO-8601, epoch, dd/mm/yyyy HH:MM) a datetime UTC
                - elimina nulos y valores atípicos (fuera de rango físico)
                - descarta duplicados (sensor_id + timestamp) y sensores inexistentes
                - enriquece: zona, GeoJSON Point, fecha/hora local (America/Bogota), nivel de alerta
 3. LOAD      : inserción masiva (bulk, idempotente) en MongoDB: colecciones `lecturas` y `sensores`.

Ejemplos
--------
  python etl_pipeline.py --dry-run                       # sin MongoDB: solo valida y genera los CSV
  python etl_pipeline.py --uri mongodb://localhost:27017 --db urbanpulse --reset
"""
import argparse
import csv
import json
import logging
import math
import sys
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path
from zoneinfo import ZoneInfo

LOG = logging.getLogger("etl_urbanpulse")
BOGOTA = ZoneInfo("America/Bogota")
AQUI = Path(__file__).resolve().parent

# ---------------------------------------------------------------------------
# Reglas de negocio (documentar en el informe técnico)
# ---------------------------------------------------------------------------
# Rangos físicamente plausibles: lo que quede fuera se considera atípico (sensor defectuoso).
RANGOS = {
    "pm25": (0.0, 500.0),             # µg/m3
    "temperatura": (-10.0, 60.0),     # °C
    "humedad": (0.0, 100.0),          # %
    "velocidad_kmh": (0.0, 160.0),
    "conteo_vehiculos": (0, 2000),
}
# Alias de campos que llegan desde fuentes distintas
ALIAS = {
    "pm25": ("pm25", "pm2_5", "PM2.5", "pm_25"),
    "temperatura": ("temperatura", "temp_c", "temp"),
    "humedad": ("humedad", "hum"),
    "velocidad_kmh": ("velocidad_kmh", "velocidad"),
    "conteo_vehiculos": ("conteo_vehiculos", "conteo"),
}
PM25_CRITICO, PM25_ALTO, PM25_MODERADO = 150.0, 55.0, 35.0   # µg/m3
VEL_CRITICA, VEL_ALTA = 8.0, 15.0                            # km/h (congestión)
UMBRAL_TRAFICO_CRITICO_ZONA = 15.0                           # velocidad promedio de zona


# ---------------------------------------------------------------------------
# Utilidades de parseo
# ---------------------------------------------------------------------------
def a_float(valor):
    """Convierte a float; devuelve None si es nulo, vacío, 'NaN' o no numérico."""
    if valor is None or isinstance(valor, bool):
        return None
    try:
        x = float(str(valor).strip().replace(",", ".")) if isinstance(valor, str) else float(valor)
    except (ValueError, TypeError):
        return None
    return None if math.isnan(x) or math.isinf(x) else x


def parsear_fecha(valor):
    """Acepta ISO-8601, epoch (s o ms) y 'dd/mm/yyyy HH:MM' (hora local Bogotá). Devuelve UTC o None."""
    if valor is None or valor == "":
        return None
    try:
        if isinstance(valor, (int, float)) or (isinstance(valor, str) and valor.strip().isdigit()):
            n = float(valor)
            n = n / 1000 if n > 1e11 else n
            return datetime.fromtimestamp(n, tz=timezone.utc)
        s = str(valor).strip()
        if "/" in s:
            return datetime.strptime(s, "%d/%m/%Y %H:%M").replace(tzinfo=BOGOTA).astimezone(timezone.utc)
        dt = datetime.fromisoformat(s.replace("Z", "+00:00"))
        return dt.astimezone(timezone.utc) if dt.tzinfo else dt.replace(tzinfo=timezone.utc)
    except (ValueError, OverflowError, OSError):
        return None


def buscar(raw, claves):
    """Busca la primera clave presente (y no nula) en el nivel superior o dentro de 'mediciones'."""
    med = raw.get("mediciones") if isinstance(raw.get("mediciones"), dict) else {}
    for k in claves:
        for fuente in (raw, med):
            if k in fuente and fuente[k] not in (None, ""):
                return k, fuente[k]
    return None, None


def haversine_km(lat1, lon1, lat2, lon2):
    r = 6371.0
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dphi, dlmb = p2 - p1, math.radians(lon2 - lon1)
    a = math.sin(dphi / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dlmb / 2) ** 2
    return 2 * r * math.asin(math.sqrt(a))


# ---------------------------------------------------------------------------
# 1. EXTRACT
# ---------------------------------------------------------------------------
def extraer_catalogo(ruta_csv):
    catalogo = {}
    with open(ruta_csv, newline="", encoding="utf-8") as f:
        for i, fila in enumerate(csv.DictReader(f), start=2):
            try:
                sid = fila["sensor_id"].strip().upper()
                catalogo[sid] = {
                    "sensor_id": sid,
                    "tipo_sensor": fila["tipo_sensor"].strip(),
                    "zona_id": fila["zona_id"].strip(),
                    "zona_nombre": fila["zona_nombre"].strip(),
                    "latitud": float(fila["latitud"]),
                    "longitud": float(fila["longitud"]),
                    "zonas_conectadas": [z for z in fila["zonas_conectadas"].split("|") if z],
                }
            except (KeyError, ValueError, AttributeError) as e:
                LOG.warning("Fila %d del catálogo ignorada (%s)", i, e)
    LOG.info("Catálogo: %d sensores", len(catalogo))
    return catalogo


def extraer_lecturas(ruta_json):
    with open(ruta_json, encoding="utf-8") as f:
        datos = json.load(f)
    if not isinstance(datos, list):
        raise ValueError("sensores_lecturas.json debe contener una lista de registros")
    LOG.info("Lecturas crudas: %d", len(datos))
    return datos


# ---------------------------------------------------------------------------
# 2. TRANSFORM
# ---------------------------------------------------------------------------
def nivel_alerta(tipo, med):
    if tipo == "calidad_aire":
        pm = med["pm25"]
        return ("critico" if pm >= PM25_CRITICO else "alto" if pm >= PM25_ALTO
                else "moderado" if pm >= PM25_MODERADO else "normal")
    v = med["velocidad_kmh"]
    return "critico" if v <= VEL_CRITICA else "alto" if v <= VEL_ALTA else "normal"


def transformar_registro(raw, catalogo, ahora_utc):
    """Devuelve (documento | None, motivo_rechazo | None, n_valores_corregidos)."""
    if not isinstance(raw, dict):
        return None, "registro_no_es_objeto", 0

    _, sid = buscar(raw, ("sensor_id", "id_sensor", "sensor"))
    sid = str(sid).strip().upper() if sid else None
    if not sid:
        return None, "sin_sensor_id", 0
    sensor = catalogo.get(sid)
    if sensor is None:
        return None, "sensor_desconocido", 0

    _, f_raw = buscar(raw, ("timestamp", "ts", "fecha"))
    ts = parsear_fecha(f_raw)
    if ts is None:
        return None, "fecha_invalida_o_nula", 0
    if ts > ahora_utc:
        return None, "fecha_futura", 0

    tipo = sensor["tipo_sensor"]                    # el catálogo es la fuente de verdad del tipo
    campos = ("pm25", "temperatura", "humedad") if tipo == "calidad_aire" else ("velocidad_kmh", "conteo_vehiculos")
    med, corregidos = {}, 0
    for campo in campos:
        _, v = buscar(raw, ALIAS[campo])
        x = a_float(v)
        if x is None and campo == "temperatura":          # temperatura en °F -> °C
            _, vf = buscar(raw, ("temp_f",))
            xf = a_float(vf)
            x = None if xf is None else round((xf - 32) * 5 / 9, 1)
        if x is None:
            continue
        lo, hi = RANGOS[campo]
        if not (lo <= x <= hi):                           # atípico -> se descarta el valor
            corregidos += 1
            continue
        med[campo] = int(x) if campo == "conteo_vehiculos" else round(x, 2)

    # Campo imprescindible según el tipo de sensor: sin él la lectura no sirve analíticamente
    imprescindible = "pm25" if tipo == "calidad_aire" else "velocidad_kmh"
    if imprescindible not in med:
        return None, f"{imprescindible}_nulo_o_atipico", corregidos

    nivel = nivel_alerta(tipo, med)
    local = ts.astimezone(BOGOTA)
    doc = {
        "sensor_id": sid,
        "tipo_sensor": tipo,
        "zona": {"id": sensor["zona_id"], "nombre": sensor["zona_nombre"]},          # incrustado (dato pequeño y estable)
        "ubicacion": {"type": "Point", "coordinates": [sensor["longitud"], sensor["latitud"]]},  # GeoJSON [lon, lat]
        "timestamp": ts,
        "fecha": local.strftime("%Y-%m-%d"),
        "hora": local.hour,
        "mediciones": med,
        "nivel_alerta": nivel,
        "es_alerta_critica": nivel == "critico",
    }
    if tipo == "trafico":
        veh = raw.get("vehiculo") if isinstance(raw.get("vehiculo"), dict) else {}
        placa = veh.get("placa") or raw.get("placa") or raw.get("vehiculo_id")
        if placa:
            doc["vehiculo_placa"] = str(placa).strip().upper()
    return doc, None, corregidos


def transformar(lecturas, catalogo):
    ahora = datetime.now(timezone.utc)
    docs, vistos = [], set()
    rechazados, motivos, valores_corregidos = [], Counter(), 0
    for raw in lecturas:
        try:
            doc, motivo, corr = transformar_registro(raw, catalogo, ahora)
        except Exception as e:                       # un registro defectuoso nunca debe tumbar el pipeline
            doc, motivo, corr = None, f"error_inesperado:{type(e).__name__}", 0
        valores_corregidos += corr
        if doc is None:
            motivos[motivo] += 1
            rechazados.append({"motivo": motivo, "registro": raw})
            continue
        clave = (doc["sensor_id"], doc["timestamp"])
        if clave in vistos:
            motivos["duplicado"] += 1
            rechazados.append({"motivo": "duplicado", "registro": raw})
            continue
        vistos.add(clave)
        docs.append(doc)
    docs.sort(key=lambda d: (d["timestamp"], d["sensor_id"]))
    resumen = {
        "lecturas_crudas": len(lecturas),
        "lecturas_validas": len(docs),
        "lecturas_rechazadas": len(rechazados),
        "valores_atipicos_descartados": valores_corregidos,
        "motivos_rechazo": dict(motivos.most_common()),
    }
    LOG.info("Transformación: %d válidas / %d rechazadas / %d valores atípicos descartados",
             len(docs), len(rechazados), valores_corregidos)
    return docs, rechazados, resumen


# ---------------------------------------------------------------------------
# 3. LOAD
# ---------------------------------------------------------------------------
def documentos_sensores(catalogo):
    return [{
        "_id": s["sensor_id"], "tipo_sensor": s["tipo_sensor"],
        "zona": {"id": s["zona_id"], "nombre": s["zona_nombre"]},
        "ubicacion": {"type": "Point", "coordinates": [s["longitud"], s["latitud"]]},
        "zonas_conectadas": s["zonas_conectadas"],
    } for s in catalogo.values()]


def cargar_mongo(docs, sensores, uri=None, nombre_db="urbanpulse", reset=False, cliente=None, lote=1000):
    """Carga masiva e idempotente. `cliente` permite inyectar un cliente (p. ej. mongomock en pruebas)."""
    from pymongo import ASCENDING
    from pymongo.errors import BulkWriteError, PyMongoError, ServerSelectionTimeoutError
    try:
        if cliente is None:
            from pymongo import MongoClient
            cliente = MongoClient(uri, serverSelectionTimeoutMS=5000)
            cliente.admin.command("ping")
        db = cliente[nombre_db]
        if reset:
            db.lecturas.drop(); db.sensores.drop()
            LOG.info("Colecciones reiniciadas")
        # El índice único (sensor_id, timestamp) hace la carga idempotente: reejecutar no duplica datos
        db.lecturas.create_index([("sensor_id", ASCENDING), ("timestamp", ASCENDING)], unique=True,
                                 name="uq_sensor_timestamp")
        db.sensores.delete_many({})
        db.sensores.insert_many(sensores)

        insertados = duplicados = 0
        for i in range(0, len(docs), lote):
            parte = docs[i:i + lote]
            try:
                insertados += len(db.lecturas.insert_many(parte, ordered=False).inserted_ids)
            except BulkWriteError as e:
                errores = e.details.get("writeErrors", [])
                duplicados += sum(1 for w in errores if w.get("code") == 11000)
                if any(w.get("code") != 11000 for w in errores):
                    raise
                insertados += e.details.get("nInserted", 0)
        LOG.info("Carga MongoDB: %d insertados, %d ya existían", insertados, duplicados)
        return {"insertados": insertados, "ya_existian": duplicados}
    except ServerSelectionTimeoutError:
        LOG.error("No se pudo conectar a MongoDB en %s. ¿Está el servicio activo? (use --dry-run para omitir la carga)", uri)
        raise
    except PyMongoError as e:
        LOG.error("Error de MongoDB: %s", e)
        raise


# ---------------------------------------------------------------------------
# Exportación para Neo4j (datos procesados)
# ---------------------------------------------------------------------------
def exportar_para_grafo(docs, catalogo, carpeta):
    carpeta.mkdir(parents=True, exist_ok=True)
    pm_por_zona, vel_por_zona = defaultdict(list), defaultdict(list)
    for d in docs:
        if d["tipo_sensor"] == "calidad_aire":
            pm_por_zona[d["zona"]["id"]].append(d["mediciones"]["pm25"])
        else:
            vel_por_zona[d["zona"]["id"]].append(d["mediciones"]["velocidad_kmh"])
    prom = lambda xs: round(sum(xs) / len(xs), 2) if xs else ""

    zonas, coords = {}, defaultdict(list)
    for s in catalogo.values():
        zonas.setdefault(s["zona_id"], {"nombre": s["zona_nombre"], "conexiones": s["zonas_conectadas"]})
        coords[s["zona_id"]].append((s["latitud"], s["longitud"]))
    # centro de cada zona = promedio de las coordenadas de sus sensores
    centro = {zid: (sum(c[0] for c in cs) / len(cs), sum(c[1] for c in cs) / len(cs)) for zid, cs in coords.items()}

    with open(carpeta / "zonas.csv", "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["id", "nombre", "latitud", "longitud", "pm25_promedio", "velocidad_promedio", "trafico_critico"])
        for zid, z in sorted(zonas.items()):
            vp = prom(vel_por_zona[zid])
            w.writerow([zid, z["nombre"], round(centro[zid][0], 6), round(centro[zid][1], 6),
                        prom(pm_por_zona[zid]), vp, "true" if vp != "" and vp < UMBRAL_TRAFICO_CRITICO_ZONA else "false"])

    with open(carpeta / "sensores.csv", "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["id", "tipo", "zona_id", "latitud", "longitud"])
        for s in sorted(catalogo.values(), key=lambda s: s["sensor_id"]):
            w.writerow([s["sensor_id"], s["tipo_sensor"], s["zona_id"], s["latitud"], s["longitud"]])

    aristas = set()
    for zid, z in zonas.items():
        for otra in z["conexiones"]:
            if otra in zonas:
                aristas.add(tuple(sorted((zid, otra))))
    with open(carpeta / "conexiones.csv", "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["origen", "destino", "distancia_km"])
        for a, b in sorted(aristas):
            w.writerow([a, b, round(haversine_km(*centro[a], *centro[b]), 3)])

    n_pasos = 0
    with open(carpeta / "pasos_vehiculos.csv", "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["placa", "sensor_id", "timestamp", "velocidad_kmh"])
        for d in docs:
            if d.get("vehiculo_placa"):
                w.writerow([d["vehiculo_placa"], d["sensor_id"], d["timestamp"].strftime("%Y-%m-%dT%H:%M:%SZ"),
                            d["mediciones"]["velocidad_kmh"]])
                n_pasos += 1
    LOG.info("CSV para Neo4j en %s (%d zonas, %d conexiones, %d pasos de vehículos)",
             carpeta, len(zonas), len(aristas), n_pasos)


# ---------------------------------------------------------------------------
def main(argv=None):
    p = argparse.ArgumentParser(description="ETL UrbanPulse IoT: JSON/CSV -> MongoDB (+ CSV para Neo4j)")
    p.add_argument("--lecturas", default=str(AQUI / "datasets" / "sensores_lecturas.json"))
    p.add_argument("--nodos", default=str(AQUI / "datasets" / "nodos_ubicacion.csv"))
    p.add_argument("--salida", default=str(AQUI / "datasets" / "procesado"))
    p.add_argument("--uri", default="mongodb://localhost:27017")
    p.add_argument("--db", default="urbanpulse")
    p.add_argument("--reset", action="store_true", help="vaciar las colecciones antes de cargar")
    p.add_argument("--dry-run", action="store_true", help="no carga en MongoDB; solo transforma y exporta")
    p.add_argument("-v", "--verbose", action="store_true")
    a = p.parse_args(argv)
    logging.basicConfig(level=logging.DEBUG if a.verbose else logging.INFO,
                        format="%(asctime)s [%(levelname)s] %(message)s", datefmt="%H:%M:%S")
    try:
        catalogo = extraer_catalogo(a.nodos)
        lecturas = extraer_lecturas(a.lecturas)
    except (OSError, json.JSONDecodeError, ValueError) as e:
        LOG.error("Fallo en la extracción: %s", e)
        return 1

    docs, rechazados, resumen = transformar(lecturas, catalogo)
    salida = Path(a.salida)
    salida.mkdir(parents=True, exist_ok=True)
    with open(salida / "rechazados.json", "w", encoding="utf-8") as f:
        json.dump(rechazados, f, ensure_ascii=False, indent=1, default=str)

    if not a.dry_run:
        try:
            resumen["carga_mongodb"] = cargar_mongo(docs, documentos_sensores(catalogo), a.uri, a.db, a.reset)
        except Exception:
            return 2
    exportar_para_grafo(docs, catalogo, salida)
    with open(salida / "etl_resumen.json", "w", encoding="utf-8") as f:
        json.dump(resumen, f, ensure_ascii=False, indent=2)
    print(json.dumps(resumen, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    sys.exit(main())
