#!/usr/bin/env python3
"""
Generador de datasets de prueba para UrbanPulse IoT.

Produce:
  - nodos_ubicacion.csv      -> catálogo de sensores, zonas, coordenadas y conexiones entre zonas
  - sensores_lecturas.json   -> lecturas heterogéneas (3 formatos distintos) con datos sucios a propósito:
                                nulos, atípicos, duplicados, sensores inexistentes, fechas inválidas.

Uso:  python generar_datasets.py            (semilla fija => resultados reproducibles)
"""
import csv
import json
import random
from datetime import datetime, timedelta, timezone
from pathlib import Path
from zoneinfo import ZoneInfo

random.seed(2026)
AQUI = Path(__file__).parent
BOGOTA = ZoneInfo("America/Bogota")

# Fin de la ventana de datos (UTC). Ventana: 48 horas, una lectura cada 30 minutos por sensor.
FIN = datetime(2026, 11, 11, 14, 0, tzinfo=timezone.utc)
INICIO = FIN - timedelta(hours=48)
PASO = timedelta(minutes=30)

# id, nombre, lat, lon, pm25_base, velocidad_base, zonas conectadas
ZONAS = [
    ("Z01", "Centro",              7.0653, -73.8547, 30, 18, ["Z02", "Z04", "Z05"]),
    ("Z02", "Terminal de Transporte", 7.0721, -73.8610, 25, 30, ["Z01", "Z03"]),
    ("Z03", "Parque Industrial",   7.0810, -73.8700, 82, 14, ["Z02", "Z07"]),
    ("Z04", "Zona Universitaria",  7.0590, -73.8480, 20, 35, ["Z01", "Z08"]),
    ("Z05", "Mercado Central",     7.0610, -73.8590, 40, 20, ["Z01", "Z06", "Z07"]),
    ("Z06", "Hospital Regional",   7.0550, -73.8630, 55, 12, ["Z05", "Z08"]),
    ("Z07", "Puerto Fluvial",      7.0700, -73.8780, 35, 32, ["Z03", "Z05"]),
    ("Z08", "Barrio Norte",        7.0490, -73.8520, 18, 40, ["Z04", "Z06"]),
]

PLACAS = [f"{random.choice('ABCDEFGHJKLMNPRSTUVWXYZ')}{random.choice('ABCDEFGHJKLMNPRSTUVWXYZ')}"
          f"{random.choice('ABCDEFGHJKLMNPRSTUVWXYZ')}{random.randint(100, 999)}" for _ in range(40)]


def construir_catalogo():
    """2 sensores de calidad del aire + 1 de tráfico por zona."""
    filas, n = [], 1
    for zid, nombre, lat, lon, _, _, conex in ZONAS:
        for tipo in ("calidad_aire", "calidad_aire", "trafico"):
            filas.append({
                "sensor_id": f"S{n:03d}", "tipo_sensor": tipo, "zona_id": zid, "zona_nombre": nombre,
                "latitud": round(lat + random.uniform(-0.0015, 0.0015), 6),
                "longitud": round(lon + random.uniform(-0.0015, 0.0015), 6),
                "zonas_conectadas": "|".join(conex),
            })
            n += 1
    return filas


def factor_horario(hora_local):
    if 6 <= hora_local <= 9 or 16 <= hora_local <= 19:
        return 1.8          # horas pico
    if hora_local >= 22 or hora_local <= 4:
        return 0.65         # madrugada
    return 1.0


def medir_aire(base, hora_local, zona_id):
    pm25 = base * factor_horario(hora_local) * random.uniform(0.85, 1.15)
    if zona_id in ("Z03", "Z06") and random.random() < 0.06:
        pm25 *= 1.7        # picos de contaminación
    temp = 22 + 6 * (1 if 11 <= hora_local <= 16 else 0) + random.uniform(-1.5, 1.5)
    hum = 75 - 15 * (1 if 11 <= hora_local <= 16 else 0) + random.uniform(-5, 5)
    return round(pm25, 1), round(temp, 1), round(hum, 1)


def medir_trafico(vel_base, hora_local):
    f = factor_horario(hora_local)
    vel = vel_base / (f if f > 1 else 1) * (1.2 if f < 1 else 1) * random.uniform(0.6, 1.2)
    conteo = int(random.uniform(10, 40) * f)
    return round(vel, 1), conteo


def a_formato(sensor, ts_utc, tipo, med, placa):
    """Devuelve el registro en uno de tres formatos heterogéneos."""
    fmt = random.choices("ABC", weights=[4, 3, 3])[0]
    local = ts_utc.astimezone(BOGOTA)
    if tipo == "calidad_aire":
        pm25, temp, hum = med
        if fmt == "A":
            return {"sensor_id": sensor, "timestamp": ts_utc.strftime("%Y-%m-%dT%H:%M:%SZ"), "tipo": tipo,
                    "mediciones": {"pm25": pm25, "temperatura": temp, "humedad": hum}}
        if fmt == "B":
            return {"id_sensor": sensor, "ts": int(ts_utc.timestamp()), "pm2_5": str(pm25),
                    "temp_c": str(temp), "hum": hum}
        return {"sensor_id": sensor, "fecha": local.strftime("%d/%m/%Y %H:%M"), "tipo": tipo,
                "PM2.5": pm25, "temp_f": round(temp * 9 / 5 + 32, 1), "humedad": hum}
    vel, conteo = med
    veh = {"placa": placa} if placa else None
    if fmt == "A":
        r = {"sensor_id": sensor, "timestamp": ts_utc.strftime("%Y-%m-%dT%H:%M:%SZ"), "tipo": tipo,
             "mediciones": {"velocidad_kmh": vel, "conteo_vehiculos": conteo}}
        if veh:
            r["vehiculo"] = veh
        return r
    if fmt == "B":
        r = {"id_sensor": sensor, "ts": int(ts_utc.timestamp()), "velocidad": str(vel), "conteo": conteo}
        if placa:
            r["placa"] = placa
        return r
    r = {"sensor_id": sensor, "fecha": local.strftime("%d/%m/%Y %H:%M"), "tipo": tipo,
         "velocidad_kmh": vel, "conteo_vehiculos": conteo}
    if veh:
        r["vehiculo"] = veh
    return r


def ensuciar(r, tipo):
    """Inyecta problemas de calidad en ~12% de los registros."""
    x = random.random()
    if x < 0.030 and tipo == "calidad_aire":
        for k in ("pm25", "pm2_5", "PM2.5"):
            if k in r:
                r[k] = random.choice([9999, -5, 1200]); return r
            if "mediciones" in r and k in r["mediciones"]:
                r["mediciones"][k] = random.choice([9999, -5, 1200]); return r
    elif x < 0.050 and tipo == "calidad_aire":
        for k in ("pm25", "pm2_5", "PM2.5"):
            if k in r:
                r[k] = random.choice([None, "", "NaN"]); return r
            if "mediciones" in r and k in r["mediciones"]:
                r["mediciones"][k] = None; return r
    elif x < 0.070 and tipo == "calidad_aire":
        for k in ("temperatura", "temp_c", "temp_f"):
            if k in r:
                r[k] = random.choice([-80, 150, 999]); return r
            if "mediciones" in r and k in r["mediciones"]:
                r["mediciones"][k] = random.choice([-80, 150]); return r
    elif x < 0.085:
        r["sensor_id" if "sensor_id" in r else "id_sensor"] = "S999"      # sensor inexistente
    elif x < 0.095:
        for k in ("timestamp", "ts", "fecha"):
            if k in r:
                r[k] = random.choice([None, "ayer por la tarde", ""]); break
    elif x < 0.105 and tipo == "trafico":
        for k in ("velocidad_kmh", "velocidad"):
            if k in r:
                r[k] = random.choice([-3, 900, None]); break
            if "mediciones" in r and k in r["mediciones"]:
                r["mediciones"][k] = random.choice([-3, 900]); break
    return r


def main():
    catalogo = construir_catalogo()
    with open(AQUI / "nodos_ubicacion.csv", "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(catalogo[0].keys()))
        w.writeheader()
        w.writerows(catalogo)

    base_zona = {z[0]: (z[4], z[5]) for z in ZONAS}
    lecturas = []
    for s in catalogo:
        t = INICIO
        while t <= FIN:
            hora_local = t.astimezone(BOGOTA).hour
            pm_base, vel_base = base_zona[s["zona_id"]]
            if s["tipo_sensor"] == "calidad_aire":
                med, placa = medir_aire(pm_base, hora_local, s["zona_id"]), None
            else:
                med = medir_trafico(vel_base, hora_local)
                placa = random.choice(PLACAS) if random.random() < 0.7 else None
            reg = ensuciar(a_formato(s["sensor_id"], t, s["tipo_sensor"], med, placa), s["tipo_sensor"])
            lecturas.append(reg)
            if random.random() < 0.02:                       # duplicados exactos
                lecturas.append(json.loads(json.dumps(reg)))
            t += PASO
    random.shuffle(lecturas)
    with open(AQUI / "sensores_lecturas.json", "w", encoding="utf-8") as f:
        json.dump(lecturas, f, ensure_ascii=False, indent=1)
    print(f"Sensores: {len(catalogo)} | Lecturas (con ruido): {len(lecturas)}")


if __name__ == "__main__":
    main()
