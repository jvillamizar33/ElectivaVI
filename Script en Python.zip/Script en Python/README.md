# UrbanPulse IoT - Proyecto integrador NoSQL

| Entregable | Archivo |
|---|---|
| Script ETL | `etl_pipeline.py` |
| Datasets de prueba | `datasets/` (`sensores_lecturas.json`, `nodos_ubicacion.csv`, `generar_datasets.py`, `procesado/`) |
| Pipelines de agregación e índices | `mongodb_pipelines.js` |
| Nodos, relaciones y consultas | `neo4j_urbanpulse.cypher` |
| Informe técnico | `Informe_Tecnico.pdf` |
| Presentación de sustentación | `Presentacion_Sustentacion.pptx` |

## Ejecución
```
pip install pymongo
python etl_pipeline.py --dry-run          # solo transforma y exporta CSV (sin MongoDB)
python etl_pipeline.py --reset            # ETL + carga en MongoDB local
mongosh mongodb_pipelines.js              # índices, consultas, explain()
# copiar datasets/procesado/*.csv a la carpeta "import" de Neo4j y ejecutar neo4j_urbanpulse.cypher
```
Requisitos: Python 3.9+, MongoDB 5+ y mongosh, Neo4j 5.x (GDS opcional).
